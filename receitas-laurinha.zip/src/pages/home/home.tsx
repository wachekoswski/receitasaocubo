import React from 'react';

import Logo from './../../assets/logo.png';
import "./home.css";
import { Link } from 'react-router-dom';

import Receipts from './../../components/source/source.json'
import { AnimatePresence, motion } from 'framer-motion';

type ReceiptsTypes = {
   id: number;
   receita: string;
   link_imagem: string;
   tipo: string;
}

const Home = () =>
{
   const [receipts] = React.useState<ReceiptsTypes[]>(Receipts);

   const [filteredReceipts, setFilteredReceipts] = React.useState<ReceiptsTypes[]>(Receipts);

   const refScroll:any = React.useRef(null);

   const MotionLink = motion(Link);

   return <>
      <section className="container">
         <img src={Logo} alt="Logo" />
      </section>
      <section ref={refScroll} className="banner">
         <h2 className="banner__titulo">Sabe como começar?</h2>
         <p className="banner__texto">Encontre aqui o que precisa para cada um de seus momentos!</p>
         <input onClick={() => refScroll && refScroll.current && refScroll.current.scrollIntoView()}  onChange={e => {
            setFilteredReceipts(receipts.filter( (item) => item.receita.match(new RegExp(e.target.value, "gi"))))
         }} type="search" className="banner__pesquisa" placeholder="Qual será sua próxima receita?" />
      </section>
      <section className="receipts__list">
         <AnimatePresence mode='popLayout'>
            {
               filteredReceipts.length > 0 ?
                  filteredReceipts.map(
                     (item) => 
                     <MotionLink
                        layout
                        // initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.8, opacity: 0 }}
                        transition={{ type: "spring" }}
                        className="receipts__item" key={`receipt__${item.id}`} to={`/receita/${item.id}`}
                     >
                        <img src={item.link_imagem} alt={item.link_imagem} />
                        <span className='receipts__item_type' >{item.tipo}</span>
                        <h3>{item.receita}</h3>
                     </MotionLink>
                  )
               :
                  <>
                     <motion.section
                        layout
                        // initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.8, opacity: 0 }}
                        transition={{ type: "spring" }}
                     className="banner">
                     </motion.section>
                     <motion.section 
                        layout
                        // initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.8, opacity: 0 }}
                        transition={{ type: "spring" }}
                        className="banner" style={{paddingInline: "2rem"}}
                     >
                        <h2 className="banner__titulo">Não encontramos receitas com sua pesquisa!</h2>
                     </motion.section>
                     <motion.section 
                        layout
                        // initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.8, opacity: 0 }}
                        transition={{ type: "spring" }} className="banner"
                     >
                     </motion.section>
                  </>
            }
         </AnimatePresence>
      </section>
   </>
}

export default Home;