import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';

import Receipts from './../../components/source/source.json';
import './receipt.css'

const Receipt = () => {

   const params = useParams();
   const navigate = useNavigate();
   
   let page_id:any = params.id && parseInt(params.id);
   
   if(!page_id)
   {
     navigate("/");
   }

   React.useEffect(
      () =>
      {
         window.scrollTo(1, 0);
      },
      []
   );

   const receipt = Receipts.filter( (item) => item.id === page_id)[0];
   
   return(
      <>
         <section className="banner banner__receipt" style={{backgroundImage: `url("${receipt.link_imagem}")`}}>
            <h1 className="banner__titulo">{receipt.receita}</h1>
            <span className='receipts__item_type'>{receipt.tipo}</span>
         </section>
         <section className="receipt">
            <h2>Ingredientes:</h2>
            <ul>
               {
                  receipt.IngredientesBase.map(
                     (rec) => {
                        return rec.nomesIngrediente.map(
                           (item, index) => <li key={`ingred__${index}_${rec.receita_id}`}>{item}</li>
                        )
                     }
                  )
               }
            </ul>
            <h2 style={{marginTop: "3rem"}}>Modo de Preparo:</h2>
            <p className='receipt__prepare'>{receipt.modo_preparo}</p>
         </section>
      </>
   )
}

export default Receipt;