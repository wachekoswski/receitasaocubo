import './App.css';
import { Routes, Route } from 'react-router-dom'
import Home from './pages/home/home'
import UpperMenu from './components/upperMenu/upperMenu';
import Receipt from './pages/receipt/receipt';

const App = () => {

  return (
    <Routes>
      <Route index={true} element={<><UpperMenu/><Home /></>} />
      <Route path='*' element={<><UpperMenu/><Home /></>} />
      <Route path='/receita/:id' element={<><UpperMenu/><Receipt /></>} />
    </Routes>
  )
}

export default App
