import React from 'react';

import './upperMenu.css'
import { GiHamburgerMenu } from "react-icons/gi";
import { IoHeartOutline } from "react-icons/io5";
import { FaRegUserCircle } from "react-icons/fa";
import { Link } from 'react-router-dom';

const UpperMenu = () => {
   const [menuOpen, setMenuOpen] = React.useState(false);

   return(
      <nav>
         <button className="buttomHamburger" onClick={() => setMenuOpen(!menuOpen)}>
            <GiHamburgerMenu />
         </button>
         <div>
            <a href="#"><IoHeartOutline /></a>
            <a href="#"><FaRegUserCircle /></a>
         </div>
         <ul className="lista-menu" aria-expanded={menuOpen}>
            <li className="lista-menu__titulo">Menu de Receitas</li>
            <li className="lista-menu__item">
               <Link to={"/"} className="lista-menu__link" onClick={() => setMenuOpen(false) }>Início</Link>
            </li>
            <li className="lista-menu__item">
               <Link to={"/"} className="lista-menu__link" onClick={() => setMenuOpen(false) }>Doces</Link>
            </li>
         
            <li className="lista-menu__item">
               <Link to={"/"} className="lista-menu__link" onClick={() => setMenuOpen(false) }>Salgadas</Link>
            </li>
            
            <li className="lista-menu__item">
               <Link to={"/"} className="lista-menu__link" onClick={() => setMenuOpen(false) }>Agridoces</Link>
            </li>
         </ul>
      </nav>
   )
}

export default UpperMenu